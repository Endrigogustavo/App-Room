package com.example.approomexemplo

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.approomaula.controller.ContatoAcoes
import com.example.approomaula.model.Contato

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdicionarDialog(
    //pega as informaçoes do model
    estado: Contato,
    //pega as informaçoes do Contato ação
    //unit = labda, todos os metodos estao pré relacionadas, da permissao de utilizar todos os metodos
    evento: (ContatoAcoes) -> Unit,
    modifier: Modifier = Modifier
){
    AlertDialog(
        modifier = modifier,
        //execultar ação
        onDismissRequest = {
                           evento(ContatoAcoes.OcultarDialog)
                           },
        title = { Text(text = "Adicionar Contato") },
        text = {
            Column(
                //Arrangement.spacedBy(8.dp) define o espaço entre componentes
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TextField(
                    value = estado.nome, 
                    onValueChange = {
                        evento(ContatoAcoes.SetNome(it))
                    },
                    placeholder = {
                        Text(text = "Nome")
                    }
                )
                TextField(
                    value = estado.sobrenome,
                    onValueChange = {
                        evento(ContatoAcoes.SetSobrenome(it))
                    },
                    placeholder = {
                        Text(text = "Sobrenome")
                    }
                )
                TextField(
                    value = estado.telefone,
                    onValueChange = {
                        evento(ContatoAcoes.SetTelefone(it))
                    },
                    placeholder = {
                        Text(text = "Telefone")
                    }
                )
                TextField(
                    value = estado.cpf,
                    onValueChange = {
                        evento(ContatoAcoes.SetCpf(it))
                    },
                    placeholder = {
                        Text(text = "CPF")
                    }
                )
                TextField(
                    value = estado.rg,
                    onValueChange = {
                        evento(ContatoAcoes.SetRg(it))
                    },
                    placeholder = {
                        Text(text = "RG")
                    }
                )
                TextField(
                    value = estado.nascimento,
                    onValueChange = {
                        evento(ContatoAcoes.SetNascimento(it))
                    },
                    placeholder = {
                        Text(text = "Nascimento")
                    }
                )
            }
        },
        confirmButton = { 
            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.CenterEnd
            ){
                Button(
                    onClick = { 
                        evento(ContatoAcoes.CadastrarContato)
                    }
                ) {
                    Text(text = "Cadastrar")
                }
            }
        }
    )
}