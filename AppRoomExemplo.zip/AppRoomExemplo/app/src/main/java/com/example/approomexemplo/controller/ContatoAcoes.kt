package com.example.approomexemplo.controller

//o Kotlin nao precisa de get e set, e sim por meio das variaveis
//metodos Set para as variaveis do banco
sealed interface ContatoAcoes{

    object CadastrarContato: ContatoAcoes
    object VisualizarDialog: ContatoAcoes
    object OcultarDialog: ContatoAcoes
    //erdando a variaval para a prorpia classe
    data class SetNome(val nome: String): ContatoAcoes
    data class SetSobrenome(val sobrenome: String): ContatoAcoes
    data class SetTelefone(val telefone: String): ContatoAcoes
    data class SetCpf(val cpf: String): ContatoAcoes
    data class SetRg(val rg: String): ContatoAcoes
    data class SetNascimento(val nascimento: String): ContatoAcoes
    data class DeletarContato(val contato: com.example.approomaula.controller.Contato): ContatoAcoes
}