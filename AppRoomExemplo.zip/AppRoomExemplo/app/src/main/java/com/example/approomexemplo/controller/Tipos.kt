package com.example.approomexemplo.controller

//tipos de variaveis/tabelas pré definidos
enum class Tipos {
    nome,
    sobrenome,
    telefone,
    rg,
    cpf,
    nascimento
}